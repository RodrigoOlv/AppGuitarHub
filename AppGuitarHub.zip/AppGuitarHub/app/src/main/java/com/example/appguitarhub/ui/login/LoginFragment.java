package com.example.appguitarhub.ui.login;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.appguitarhub.R;
import com.example.appguitarhub.ui.home.HomeFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginFragment extends Fragment {

    private FirebaseAuth mAuth;
    private TextInputEditText email;
    private TextInputEditText password;
    private Button login;
    private Button register;
    private Context context;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        context = getContext();
        email = view.findViewById(R.id.edtEmail);
        password = view.findViewById(R.id.edtPassword);
        login = view.findViewById(R.id.btnLogin);
        register = view.findViewById(R.id.btnRegister);

        if ( isLogged() ) {
            openMainFragment(view);
        }
        else {
            login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if ( !email.getText().equals("") && !password.getText().toString().equals("") )
                        valiidateLogin(view, email.getText().toString(), password.getText().toString());
                    else
                        Snackbar.make(view, "Informe email e senha", Snackbar.LENGTH_LONG).show();
                }
            });
        }

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.action_nav_login_to_nav_register_user);
            }
        });

        mAuth = FirebaseAuth.getInstance();

        return view;
    }

    private Boolean isLogged() {
        Log.d("Login", "instance" + FirebaseAuth.getInstance());

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser == null)
            return false;

        return true;
    }

    private void openMainFragment(View view) {
        Navigation.findNavController(view).navigate(R.id.action_nav_login_to_nav_home);
    }

    private void valiidateLogin(View view, String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if ( task.isSuccessful() ) {
                    openMainFragment(view);
                    Snackbar.make(view, "Sucesso", Snackbar.LENGTH_LONG).show();
                }
                else {
                    Snackbar.make(view, "Dados inválidos", Snackbar.LENGTH_LONG).show();
                    Log.d("LOGIN", "dados inválidos!");
                }
            }
        });
    }
}