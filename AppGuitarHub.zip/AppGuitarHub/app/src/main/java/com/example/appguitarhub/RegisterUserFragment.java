package com.example.appguitarhub;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterUserFragment extends Fragment {

    private FirebaseAuth mAuth;
    private TextInputEditText email;
    private TextInputEditText password;
    private TextInputEditText confPass;
    private Button register;
    private Button cancel;
    private Context context;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        context = getContext();
        email = view.findViewById(R.id.edtEmail);
        password = view.findViewById(R.id.edtPassword);
        confPass = view.findViewById(R.id.edtPassword);
        register = view.findViewById(R.id.btnRegister);
        cancel = view.findViewById(R.id.btnRegister);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (
                    !email.getText().toString().equals("") &&
                    !password.getText().toString().equals("") &&
                    !confPass.getText().toString().equals("")
                ) {
                    if ( password.getText().toString().equals(confPass.getText().toString()) ) {
                        mAuth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString())
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if ( task.isSuccessful() ) {
                                        Navigation.findNavController(view).navigate(R.id.action_nav_register_user_to_nav_home);
                                        Snackbar.make(view, "Sucesso", Snackbar.LENGTH_LONG).show();
                                    }
                                    else
                                        Snackbar.make(view, "Erro ao cadastrar usuário", Snackbar.LENGTH_LONG).show();
                                }
                            });
                    }
                    else {
                        Snackbar.make(view, "Senha e onfirmação de senha devem ser iguais", Snackbar.LENGTH_LONG).show();
                    }
                }
                else {
                    Snackbar.make(view, "Informe os dados para o cadastro", Snackbar.LENGTH_LONG).show();
                }
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.signOut();
                Navigation.findNavController(view).navigate(R.id.action_nav_register_user_to_nav_home);
            }
        });

        mAuth = FirebaseAuth.getInstance();

        return view;
    }
}